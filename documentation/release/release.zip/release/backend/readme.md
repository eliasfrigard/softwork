# backend

This folder contains the backend code of the Softwork application. Install and run the code using the commands below. Backend is build with express.js.

## Project setup
```
npm install
```

### Compiles for development
```
npm start
```

### Lints and fixes files
```
npm run lint
```