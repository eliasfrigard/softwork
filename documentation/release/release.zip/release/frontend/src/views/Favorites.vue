<template>
  <div>
    <Favorites />
  </div>
</template>

<script>
/**
 * @author Karl Ekberg
 */
import Favorites from "../components/Favorites";

export default {
  components: { Favorites },
};
</script>

<style></style>
