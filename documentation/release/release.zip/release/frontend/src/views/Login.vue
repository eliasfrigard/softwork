<template>
<div>
  <Login />
</div>
</template>

<script>
/**
 * @author Karl Ekberg
 */
import Login from '../components/Login'
export default {
  components: { Login }

}
</script>

<style>

</style>