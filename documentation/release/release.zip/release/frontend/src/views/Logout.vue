<template><div></div> </template>

<script>
import {
    useRouter
} from "vue-router";

export default {
  setup() {
    const router = useRouter()
    router.push('/')
  },
};
</script>

<style></style>
