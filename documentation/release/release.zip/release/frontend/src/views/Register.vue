<template>
<div>
  <Register />
</div>
</template>

<script>
/**
 * @author Karl Ekberg
 */
import Register from '../components/Register'
export default {
  components: { Register }

}
</script>

<style>

</style>