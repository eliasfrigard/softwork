// // in your vue.config.js
// module.exports = {
//     /* ... other config ... */
//     transpileDependencies: ['vuex-persist']
//   }