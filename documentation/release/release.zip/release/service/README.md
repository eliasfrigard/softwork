# Service

This folder contains the source code for the job service. Install and run the code using the commands below. Edit the .env file in the root folder to change settings such as the default port.

## Project setup
```
npm install
```

### Start program
```
npm start
```
