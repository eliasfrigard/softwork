/**
 * Platsbanken routes
 */

import express from 'express'
// import Platsbanken from '../platsbanken/Platsbanken.js'

export const router = express.Router()

// const controller = new Platsbanken();

// router.get('/ads', controller.getAds);
